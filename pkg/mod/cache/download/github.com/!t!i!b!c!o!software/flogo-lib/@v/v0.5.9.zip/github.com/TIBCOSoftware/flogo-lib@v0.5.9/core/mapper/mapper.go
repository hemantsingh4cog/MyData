package mapper

import (
	"fmt"
	"github.com/TIBCOSoftware/flogo-lib/core/mapper/assign"

	"encoding/json"
	"strings"

	"github.com/TIBCOSoftware/flogo-lib/core/data"
	"github.com/TIBCOSoftware/flogo-lib/core/mapper/exprmapper"
	"github.com/TIBCOSoftware/flogo-lib/logger"
)

var mapplerLog = logger.GetLogger("basic-mapper")

type Factory interface {
	// NewMapper creates a new data.Mapper from the specified data.MapperDef
	NewMapper(mapperDef *data.MapperDef, resolver data.Resolver) data.Mapper

	// NewUniqueMapper creates a unique data.Mapper from the specified data.MapperDef
	// the ID can be used to facilitate use precompiled mappers
	NewUniqueMapper(ID string, mapperDef *data.MapperDef, resolver data.Resolver) data.Mapper
}

var factory Factory

func SetFactory(factory Factory) {
	factory = factory
}

func GetFactory() Factory {

	if factory == nil {
		factory = &BasicMapperFactory{}
	}

	return factory
}

type BasicMapperFactory struct {
}

func (mf *BasicMapperFactory) NewMapper(mapperDef *data.MapperDef, resolver data.Resolver) data.Mapper {
	return NewBasicMapper(mapperDef, resolver)
}

func (mf *BasicMapperFactory) NewUniqueMapper(ID string, mapperDef *data.MapperDef, resolver data.Resolver) data.Mapper {
	return NewBasicMapper(mapperDef, resolver)
}

// BasicMapper is a simple object holding and executing mappings
type BasicMapper struct {
	mappings []*data.MappingDef
	resolver data.Resolver
}

// NewBasicMapper creates a new BasicMapper with the specified mappings
func NewBasicMapper(mapperDef *data.MapperDef, resolver data.Resolver) data.Mapper {

	var mapper BasicMapper
	mapper.mappings = mapperDef.Mappings

	if resolver == nil {
		mapper.resolver = &data.BasicResolver{}
	} else {
		mapper.resolver = resolver
	}

	return &mapper
}

// Mappings gets the mappings of the BasicMapper
func (m *BasicMapper) Mappings() []*data.MappingDef {
	return m.mappings
}

// Apply executes the mappings using the values from the input scope
// and puts the results in the output scope
//
// return error
func (m *BasicMapper) Apply(inputScope data.Scope, outputScope data.Scope) error {

	if err := m.UpdateMapping(); err != nil {
		return fmt.Errorf("Update mapping ref error %s", err.Error())
	}

	//todo validate types
	for _, mapping := range m.mappings {

		switch mapping.Type {
		case data.MtAssign:
			err := assign.MapAssign(mapping, inputScope, outputScope, m.resolver)
			if err != nil {
				return fmt.Errorf("assign mapping failed, due to %s", err.Error())
			}
		case data.MtLiteral:
			err := assign.SetValueToOutputScope(mapping.MapTo, outputScope, mapping.Value)
			if err != nil {
				err = fmt.Errorf("set value %+v to output [%s] error - %s", mapping.Value, mapping.MapTo, err.Error())
				mapplerLog.Error(err)
				return err
			}
		case data.MtObject:

			val, err := MapObject(mapping.Value, inputScope, m.resolver)
			if err != nil {
				return err
			}
			err = assign.SetValueToOutputScope(mapping.MapTo, outputScope, val)
			if err != nil {
				err = fmt.Errorf("set value %+v to output [%s] error - %s", val, mapping.MapTo, err.Error())
				mapplerLog.Error(err)
				return err
			}
		case data.MtExpression:
			err := exprmapper.MapExpreesion(mapping, inputScope, outputScope, m.resolver)
			if err != nil {
				return fmt.Errorf("expression mapping failed, due to %s", err.Error())
			}
		case data.MtArray:
			//ArrayMapping
			mapplerLog.Debugf("Array mapping value %s", mapping.Value)
			//Array mapping value must be string
			arrayMapping, err := exprmapper.ParseArrayMapping(mapping.Value)
			if err != nil {
				return fmt.Errorf("array mapping structure error -  %s", err.Error())
			}

			if err := arrayMapping.Validate(); err != nil {
				return err
			}
			if err = arrayMapping.DoArrayMapping(inputScope, outputScope, m.resolver); err != nil {
				return fmt.Errorf("array mapping error - %s", err.Error())
			}

		}

	}

	return nil
}

func (m *BasicMapper) UpdateMapping() error {
	var newMappingDefs []*data.MappingDef
	for _, mapping := range m.mappings {
		var mappingDef *data.MappingDef
		//Remove all $INPUT for mapTo include array mapping
		if mapping.MapTo != "" && strings.HasPrefix(mapping.MapTo, exprmapper.MAP_TO_INPUT) {
			mappingDef = &data.MappingDef{Type: mapping.Type, Value: mapping.Value, MapTo: exprmapper.RemovePrefixInput(mapping.MapTo)}
		} else {
			mappingDef = mapping
		}

		switch mappingDef.Type {
		//Array mapping
		case data.MtArray:
			//Update Array Mapping
			arrayMapping, err := exprmapper.ParseArrayMapping(mapping.Value)
			if err != nil {
				return fmt.Errorf("Array mapping structure error -  %s", err.Error())
			}

			arrayMapping.RemovePrefixForMapTo()
			v, err := json.Marshal(arrayMapping)
			if err != nil {
				return err
			}
			mappingDef.Value = string(v)
		}
		mapplerLog.Debugf("Updated mapping def %+v", mappingDef)
		newMappingDefs = append(newMappingDefs, mappingDef)
	}
	m.mappings = newMappingDefs
	return nil
}
